# Predicting cuisine recipes - Data Mining and Exploration project repository

This repository contains the files in the mini-project.
